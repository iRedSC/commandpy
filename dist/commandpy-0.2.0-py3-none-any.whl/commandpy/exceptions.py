class EngineNotRegistered(Exception):
    pass


class InjectCommandError(Exception):
    pass
