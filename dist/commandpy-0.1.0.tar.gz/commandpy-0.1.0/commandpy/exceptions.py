class EngineNotRegistered(Exception):
    pass


class PassCommandError(Exception):
    pass
